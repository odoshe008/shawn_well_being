Upload these files to your GitHub repo 'shawn-well-being' and enable GitHub Pages (source: main / root). Site URL: https://odoshe008.github.io/shawn-well-being/
